"""
FastAPI Backend for Mecca Halal Food & Sadaqah Store.
Handles inventory management, order processing, receipts, and settings.
"""
import os
import hmac
import hashlib
import json
import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from urllib.parse import parse_qs, unquote

import aiofiles
from fastapi import FastAPI, Depends, HTTPException, Query, UploadFile, File, Form, Header, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import select, update, func, desc
from sqlalchemy.ext.asyncio import AsyncSession
from dotenv import load_dotenv

from database.db import get_db, init_db
from database.models import (
    User, Product, Category, Order, OrderItem, BusinessSetting, InventoryTransaction
)
from database.seed import seed_data
from bot.main import send_order_notification_to_admins

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]

app = FastAPI(
    title="Mecca Halal Food & Sadaqah Store API",
    description="Backend API for Telegram Mini App in Mecca",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "..", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.on_event("startup")
async def startup_event():
    await init_db()
    # Seed database if clean
    try:
        await seed_data()
    except Exception as e:
        logger.warning(f"Seed completed or skipped: {e}")


# ==========================================
# PYDANTIC SCHEMAS
# ==========================================

class LocalizedText(BaseModel):
    ru: str
    uz: str
    ar: str
    en: str


class ProductCreate(BaseModel):
    id: Optional[str] = None
    section: str = "menu"  # 'menu' or 'sadaqah'
    category_id: str
    name_ru: str
    name_uz: str
    name_ar: str
    name_en: str
    description_ru: Optional[str] = ""
    description_uz: Optional[str] = ""
    description_ar: Optional[str] = ""
    description_en: Optional[str] = ""
    price: float = Field(..., gt=0)
    stock: int = Field(..., ge=0)
    photo_url: Optional[str] = ""
    is_available: bool = True
    is_set: bool = False
    min_quantity: int = 1
    max_quantity: Optional[int] = None


class ProductUpdate(BaseModel):
    section: Optional[str] = None
    category_id: Optional[str] = None
    name_ru: Optional[str] = None
    name_uz: Optional[str] = None
    name_ar: Optional[str] = None
    name_en: Optional[str] = None
    description_ru: Optional[str] = None
    description_uz: Optional[str] = None
    description_ar: Optional[str] = None
    description_en: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None
    photo_url: Optional[str] = None
    is_available: Optional[bool] = None
    is_set: Optional[bool] = None
    min_quantity: Optional[int] = None
    max_quantity: Optional[int] = None


class OrderItemCreate(BaseModel):
    product_id: str
    quantity: int = Field(..., gt=0)


class OrderCreate(BaseModel):
    client_name: str
    client_phone: str
    client_telegram_id: Optional[int] = None
    client_telegram_username: Optional[str] = None
    delivery_type: str = "delivery"  # 'delivery' or 'pickup'
    delivery_address: str
    comment: Optional[str] = None
    payment_method: str = "cash"  # 'cash' or 'transfer'
    receipt_url: Optional[str] = None
    items: List[OrderItemCreate]


class StatusUpdate(BaseModel):
    status: str
    return_stock_on_cancel: bool = True


# ==========================================
# AUTH / TELEGRAM INITDATA VALIDATION
# ==========================================

def verify_telegram_init_data(init_data: str) -> Optional[dict]:
    """
    Validates Telegram WebApp initData HMAC-SHA256 signature against BOT_TOKEN.
    """
    if not BOT_TOKEN or not init_data:
        return None

    try:
        parsed_data = dict(parse_qs(init_data))
        hash_check = parsed_data.get("hash", [""])[0]
        if not hash_check:
            return None

        # Build data check string
        data_check_arr = []
        for k in sorted(parsed_data.keys()):
            if k != "hash":
                data_check_arr.append(f"{k}={parsed_data[k][0]}")
        data_check_string = "\n".join(data_check_arr)

        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

        if calc_hash == hash_check:
            user_json = parsed_data.get("user", ["{}"])[0]
            return json.loads(user_json)
        return None
    except Exception as e:
        logger.error(f"Error verifying Telegram initData: {e}")
        return None


# ==========================================
# API ENDPOINTS: SETTINGS
# ==========================================

@app.get("/api/settings")
async def get_settings(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(BusinessSetting))
    rows = result.scalars().all()
    data = {row.key: row.value for row in rows}
    return data


@app.put("/api/settings")
async def update_settings(payload: Dict[str, Any], db: AsyncSession = Depends(get_db)):
    for k, v in payload.items():
        existing = await db.get(BusinessSetting, k)
        if existing:
            existing.value = str(v)
        else:
            db.add(BusinessSetting(key=k, value=str(v)))
    await db.commit()
    return {"success": True, "message": "Settings updated"}


# ==========================================
# API ENDPOINTS: PRODUCTS & CATEGORIES
# ==========================================

@app.get("/api/categories")
async def get_categories(
    section: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    query = select(Category).order_by(Category.sort_order)
    if section:
        query = query.where(Category.section == section)
    result = await db.execute(query)
    categories = result.scalars().all()
    return categories


@app.get("/api/products")
async def get_products(
    section: Optional[str] = None,
    category_id: Optional[str] = None,
    only_available: bool = False,
    db: AsyncSession = Depends(get_db)
):
    query = select(Product)
    if section:
        query = query.where(Product.section == section)
    if category_id and category_id != "all":
        query = query.where(Product.category_id == category_id)
    if only_available:
        query = query.where(Product.is_available == True)

    result = await db.execute(query.order_by(Product.is_set.desc(), Product.created_at.desc()))
    products = result.scalars().all()
    
    # Format for JSON response
    items = []
    for p in products:
        items.append({
            "id": p.id,
            "section": p.section,
            "category_id": p.category_id,
            "is_set": p.is_set,
            "name": {
                "ru": p.name_ru,
                "uz": p.name_uz,
                "ar": p.name_ar,
                "en": p.name_en
            },
            "description": {
                "ru": p.description_ru,
                "uz": p.description_uz,
                "ar": p.description_ar,
                "en": p.description_en
            },
            "price": p.price,
            "stock": p.stock,
            "photo_url": p.photo_url,
            "is_available": p.is_available,
            "min_quantity": p.min_quantity,
            "max_quantity": p.max_quantity
        })
    return items


@app.post("/api/products")
async def create_product(product: ProductCreate, db: AsyncSession = Depends(get_db)):
    prod_id = product.id or f"prod-{int(datetime.utcnow().timestamp())}"
    new_product = Product(
        id=prod_id,
        section=product.section,
        category_id=product.category_id,
        name_ru=product.name_ru,
        name_uz=product.name_uz,
        name_ar=product.name_ar,
        name_en=product.name_en,
        description_ru=product.description_ru or "",
        description_uz=product.description_uz or "",
        description_ar=product.description_ar or "",
        description_en=product.description_en or "",
        price=product.price,
        stock=product.stock,
        photo_url=product.photo_url or "",
        is_available=product.is_available,
        is_set=product.is_set,
        min_quantity=product.min_quantity,
        max_quantity=product.max_quantity
    )
    db.add(new_product)
    await db.commit()
    return {"success": True, "product_id": prod_id}


@app.put("/api/products/{product_id}")
async def update_product(product_id: str, updates: ProductUpdate, db: AsyncSession = Depends(get_db)):
    prod = await db.get(Product, product_id)
    if not prod:
        raise HTTPException(status_code=404, detail="Товар не найден")

    update_dict = updates.dict(exclude_unset=True)
    for key, val in update_dict.items():
        if hasattr(prod, key):
            setattr(prod, key, val)

    # Automatic availability toggle if stock hits 0
    if updates.stock is not None:
        if updates.stock <= 0:
            prod.is_available = False
        elif not prod.is_available and updates.stock > 0:
            prod.is_available = True

    await db.commit()
    return {"success": True, "message": "Товар успешно обновлен"}


@app.delete("/api/products/{product_id}")
async def delete_product(product_id: str, db: AsyncSession = Depends(get_db)):
    prod = await db.get(Product, product_id)
    if not prod:
        raise HTTPException(status_code=404, detail="Товар не найден")
    await db.delete(prod)
    await db.commit()
    return {"success": True, "message": "Товар удален"}


# ==========================================
# API ENDPOINTS: ORDERS (ATOMIC STOCK RESERVATION)
# ==========================================

@app.post("/api/orders")
async def place_order(order_in: OrderCreate, db: AsyncSession = Depends(get_db)):
    """
    CRITICAL: Atomic database transaction with stock decrement.
    Prevents race conditions and negative inventory.
    """
    if not order_in.items:
        raise HTTPException(status_code=400, detail="Корзина пуста")

    # 1. Check Store Open Hours
    res_open = await db.execute(select(BusinessSetting).where(BusinessSetting.key == "is_open"))
    is_open_setting = res_open.scalar_one_or_none()
    res_allow = await db.execute(select(BusinessSetting).where(BusinessSetting.key == "allow_orders_when_closed"))
    allow_closed = res_allow.scalar_one_or_none()

    if is_open_setting and is_open_setting.value.lower() == "false":
        if not (allow_closed and allow_closed.value.lower() == "true"):
            raise HTTPException(
                status_code=403, 
                detail="Магазин сейчас закрыт. Прием заказов временно приостановлен."
            )

    # 2. Start Atomic Lock & Stock Verification
    total_amount = 0.0
    items_to_create = []
    inventory_logs = []

    for item_req in order_in.items:
        # Fetch current product state
        prod = await db.get(Product, item_req.product_id)
        if not prod:
            raise HTTPException(status_code=404, detail=f"Товар ID {item_req.product_id} не найден")

        if not prod.is_available or prod.stock <= 0:
            raise HTTPException(
                status_code=400, 
                detail=f"Товара «{prod.name_ru}» нет в наличии."
            )

        if prod.stock < item_req.quantity:
            raise HTTPException(
                status_code=400, 
                detail=f"Извините, для «{prod.name_ru}» осталось только {prod.stock} шт."
            )

        # Decrement stock safely
        stock_before = prod.stock
        prod.stock -= item_req.quantity
        if prod.stock == 0:
            prod.is_available = False

        subtotal = round(prod.price * item_req.quantity, 2)
        total_amount += subtotal

        items_to_create.append({
            "product_id": prod.id,
            "product_name": prod.name_ru,
            "quantity": item_req.quantity,
            "unit_price": prod.price,
            "subtotal": subtotal
        })

        inventory_logs.append({
            "product_id": prod.id,
            "delta": -item_req.quantity,
            "stock_before": stock_before,
            "stock_after": prod.stock,
            "reason": "order_placed"
        })

    # 3. Generate Next Order Number
    res_max = await db.execute(select(func.max(Order.order_number)))
    max_num = res_max.scalar() or 1000
    next_order_number = max_num + 1

    order_id = f"ord-{next_order_number}-{int(datetime.utcnow().timestamp())}"
    initial_status = "verifying_payment" if (order_in.payment_method == "transfer" and order_in.receipt_url) else (
        "pending_payment" if order_in.payment_method == "transfer" else "new"
    )

    new_order = Order(
        id=order_id,
        order_number=next_order_number,
        client_name=order_in.client_name,
        client_phone=order_in.client_phone,
        client_telegram_id=order_in.client_telegram_id,
        client_telegram_username=order_in.client_telegram_username,
        delivery_type=order_in.delivery_type,
        delivery_address=order_in.delivery_address,
        comment=order_in.comment,
        total_amount=round(total_amount, 2),
        payment_method=order_in.payment_method,
        receipt_url=order_in.receipt_url,
        status=initial_status
    )
    db.add(new_order)

    # Add items
    for it in items_to_create:
        db.add(OrderItem(
            order_id=order_id,
            product_id=it["product_id"],
            product_name=it["product_name"],
            quantity=it["quantity"],
            unit_price=it["unit_price"],
            subtotal=it["subtotal"]
        ))

    # Add inventory transactions
    for log in inventory_logs:
        db.add(InventoryTransaction(
            product_id=log["product_id"],
            order_id=order_id,
            delta=log["delta"],
            stock_before=log["stock_before"],
            stock_after=log["stock_after"],
            reason=log["reason"]
        ))

    # Commit transaction atomically
    await db.commit()

    # 4. Trigger Telegram Notification
    order_notification_dict = {
        "id": order_id,
        "order_number": next_order_number,
        "client_name": order_in.client_name,
        "client_phone": order_in.client_phone,
        "delivery_type": order_in.delivery_type,
        "delivery_address": order_in.delivery_address,
        "payment_method": order_in.payment_method,
        "total_amount": round(total_amount, 2),
        "comment": order_in.comment,
        "receipt_url": order_in.receipt_url,
        "items": items_to_create
    }

    try:
        import asyncio
        asyncio.create_task(send_order_notification_to_admins(order_notification_dict))
    except Exception as e:
        logger.error(f"Failed to queue admin notification: {e}")

    return {
        "success": True,
        "order_id": order_id,
        "order_number": next_order_number,
        "status": initial_status,
        "total_amount": round(total_amount, 2)
    }


@app.get("/api/orders")
async def list_orders(
    status: Optional[str] = None,
    client_telegram_id: Optional[int] = None,
    limit: int = 50,
    db: AsyncSession = Depends(get_db)
):
    query = select(Order).order_by(Order.created_at.desc()).limit(limit)
    if status:
        query = query.where(Order.status == status)
    if client_telegram_id:
        query = query.where(Order.client_telegram_id == client_telegram_id)

    result = await db.execute(query)
    orders = result.scalars().all()

    orders_data = []
    for o in orders:
        items_res = await db.execute(select(OrderItem).where(OrderItem.order_id == o.id))
        items = items_res.scalars().all()

        orders_data.append({
            "id": o.id,
            "order_number": o.order_number,
            "created_at": o.created_at.isoformat() if o.created_at else "",
            "client_name": o.client_name,
            "client_phone": o.client_phone,
            "client_telegram_id": o.client_telegram_id,
            "client_telegram_username": o.client_telegram_username,
            "delivery_type": o.delivery_type,
            "delivery_address": o.delivery_address,
            "comment": o.comment,
            "total_amount": o.total_amount,
            "payment_method": o.payment_method,
            "receipt_url": o.receipt_url,
            "status": o.status,
            "items": [
                {
                    "product_id": it.product_id,
                    "product_name": it.product_name,
                    "quantity": it.quantity,
                    "unit_price": it.unit_price,
                    "subtotal": it.subtotal
                } for it in items
            ]
        })
    return orders_data


@app.post("/api/orders/{order_id}/receipt")
async def upload_receipt(
    order_id: str,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db)
):
    order = await db.get(Order, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")

    # Save uploaded receipt image to disk
    file_ext = os.path.splitext(file.filename)[1] or ".jpg"
    safe_filename = f"receipt_{order.order_number}_{int(datetime.utcnow().timestamp())}{file_ext}"
    file_path = os.path.join(UPLOAD_DIR, safe_filename)

    content = await file.read()
    async with aiofiles.open(file_path, "wb") as f:
        await f.write(content)

    receipt_url = f"/uploads/{safe_filename}"
    order.receipt_url = receipt_url
    order.status = "verifying_payment"
    await db.commit()

    # Notify admins about uploaded receipt
    try:
        order_notification_dict = {
            "id": order.id,
            "order_number": order.order_number,
            "client_name": order.client_name,
            "client_phone": order.client_phone,
            "delivery_type": order.delivery_type,
            "delivery_address": order.delivery_address,
            "payment_method": "transfer",
            "total_amount": order.total_amount,
            "receipt_url": receipt_url,
            "comment": "Клиент прикрепил квитанцию об оплате!",
            "items": []
        }
        import asyncio
        asyncio.create_task(send_order_notification_to_admins(order_notification_dict, receipt_bytes=content))
    except Exception as e:
        logger.error(f"Failed to notify admins about receipt: {e}")

    return {"success": True, "receipt_url": receipt_url, "status": "verifying_payment"}


@app.post("/api/orders/{order_id}/status")
async def update_order_status(
    order_id: str,
    payload: StatusUpdate,
    db: AsyncSession = Depends(get_db)
):
    order = await db.get(Order, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")

    prev_status = order.status
    order.status = payload.status

    # If cancelling, optionally return reserved stock back to inventory
    if payload.status == "cancelled" and prev_status != "cancelled" and payload.return_stock_on_cancel:
        items_res = await db.execute(select(OrderItem).where(OrderItem.order_id == order_id))
        items = items_res.scalars().all()
        for it in items:
            prod = await db.get(Product, it.product_id)
            if prod:
                stock_before = prod.stock
                prod.stock += it.quantity
                prod.is_available = True
                db.add(InventoryTransaction(
                    product_id=prod.id,
                    order_id=order_id,
                    delta=it.quantity,
                    stock_before=stock_before,
                    stock_after=prod.stock,
                    reason="order_cancelled"
                ))

    await db.commit()
    return {"success": True, "new_status": payload.status}


@app.get("/api/stats")
async def get_stats(db: AsyncSession = Depends(get_db)):
    """
    Calculates admin statistics for today, week, month, bestsellers, low stock.
    """
    now = datetime.utcnow()
    today_start = datetime(now.year, now.month, now.day)
    week_start = now - timedelta(days=7)
    month_start = now - timedelta(days=30)

    # Today orders
    res_today = await db.execute(
        select(func.count(Order.id), func.coalesce(func.sum(Order.total_amount), 0.0))
        .where(Order.created_at >= today_start, Order.status != "cancelled")
    )
    today_count, today_rev = res_today.one()

    # Week orders
    res_week = await db.execute(
        select(func.count(Order.id)).where(Order.created_at >= week_start, Order.status != "cancelled")
    )
    week_count = res_week.scalar() or 0

    # Month orders
    res_month = await db.execute(
        select(func.count(Order.id)).where(Order.created_at >= month_start, Order.status != "cancelled")
    )
    month_count = res_month.scalar() or 0

    # Low stock alert
    res_low = await db.execute(select(Product).where(Product.stock <= 3))
    low_stock = [{"name": p.name_ru, "stock": p.stock} for p in res_low.scalars().all()]

    return {
        "today_orders_count": today_count,
        "today_revenue": round(today_rev, 2),
        "week_orders_count": week_count,
        "month_orders_count": month_count,
        "low_stock_products": low_stock
    }
