"""
Telegram Bot for Mecca Halal Food & Sadaqah Store.
Powered by aiogram 3.x.
"""
import os
import logging
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    InlineKeyboardMarkup, 
    InlineKeyboardButton, 
    WebAppInfo, 
    MenuButtonWebApp
)
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://yourdomain.com")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(
    token=BOT_TOKEN, 
    default=DefaultBotProperties(parse_mode=ParseMode.HTML)
) if BOT_TOKEN else None

dp = Dispatcher()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def get_main_keyboard(user_id: int) -> InlineKeyboardMarkup:
    buttons = [
        [
            InlineKeyboardButton(
                text="🛍 Открыть магазин еды и садака",
                web_app=WebAppInfo(url=WEBAPP_URL)
            )
        ]
    ]

    # Admin only button
    if is_admin(user_id):
        buttons.append([
            InlineKeyboardButton(
                text="👨‍💼 Админ-панель магазина",
                web_app=WebAppInfo(url=f"{WEBAPP_URL}?admin=true")
            )
        ])

    return InlineKeyboardMarkup(inline_keyboard=buttons)


@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    user_name = message.from_user.first_name or "Гость"
    user_id = message.from_user.id
    
    welcome_text = (
        f"<b>Ассаляму алейкум ва рахматуллахи ва баракатух, {user_name}! 🌙</b>\n\n"
        f"Добро пожаловать в службу доставки халяль еды и садака в <b>Священной Мекке</b>.\n\n"
        f"🍽 <b>Горячее МЕНЮ:</b> Наш фирменный сет, традиционный плов, арабский манди, шакшука, шурпа и священная вода Замзам.\n"
        f"🤲 <b>САДАКА:</b> Организация благотворительного питания и раздачи питьевой воды паломникам и постящимся в Мекке.\n\n"
        f"📦 Быстрая доставка по отелям и районам Мекки.\n"
        f"💵 Оплата наличными курьеру или 🏦 банковским переводом.\n\n"
        f"Нажмите кнопку ниже, чтобы открыть магазин 👇"
    )

    await message.answer(
        text=welcome_text,
        reply_markup=get_main_keyboard(user_id)
    )

    # Configure WebApp Menu Button
    try:
        await bot.set_chat_menu_button(
            chat_id=message.chat.id,
            menu_button=MenuButtonWebApp(
                text="🛍 Меню и Садака",
                web_app=WebAppInfo(url=WEBAPP_URL)
            )
        )
    except Exception as e:
        logger.warning(f"Could not set chat menu button: {e}")


@dp.message(Command("admin"))
async def cmd_admin(message: types.Message):
    user_id = message.from_user.id
    if not is_admin(user_id):
        await message.answer("⛔ Доступ к панели администратора запрещен.")
        return

    admin_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📊 Открыть панель управления",
                web_app=WebAppInfo(url=f"{WEBAPP_URL}?admin=true")
            )
        ]
    ])

    await message.answer(
        "<b>Панель администратора Mecca Halal Store:</b>\n"
        "Управление остатками, товарами, проверка чеков и статусов заказов доступна по кнопке ниже:",
        reply_markup=admin_keyboard
    )


async def send_order_notification_to_admins(order_data: dict, receipt_bytes: bytes = None):
    """
    Sends formatted notification to all ADMIN_IDS in Telegram when a new order arrives.
    """
    if not bot:
        logger.warning("Bot is not initialized, skipping admin notification.")
        return

    order_num = order_data.get("order_number", "---")
    client_name = order_data.get("client_name", "---")
    phone = order_data.get("client_phone", "---")
    address = order_data.get("delivery_address", "---")
    del_type = "🚚 Доставка" if order_data.get("delivery_type") == "delivery" else "🏬 Самовывоз"
    payment_method = "💵 Наличными курьеру" if order_data.get("payment_method") == "cash" else "🏦 Банковский перевод"
    total = order_data.get("total_amount", 0)
    comment = order_data.get("comment", "")
    order_id = order_data.get("id", "")

    # Format items list
    items_text = ""
    for item in order_data.get("items", []):
        name = item.get("product_name")
        qty = item.get("quantity")
        subtotal = item.get("subtotal")
        items_text += f"▫️ {name} × {qty} — <b>{subtotal} SAR</b>\n"

    msg = (
        f"🔔 <b>НОВЫЙ ЗАКАЗ №{order_num}</b>\n\n"
        f"👤 <b>Клиент:</b> {client_name}\n"
        f"📞 <b>Телефон:</b> {phone}\n"
        f"📍 <b>Адрес:</b> {address} ({del_type})\n"
    )
    if comment:
        msg += f"💬 <b>Комментарий:</b> {comment}\n"

    msg += (
        f"\n<b>Состав заказа:</b>\n{items_text}\n"
        f"💰 <b>Итого: {total} SAR</b>\n"
        f"💳 <b>Оплата:</b> {payment_method}\n"
    )

    if order_data.get("payment_method") == "transfer":
        if order_data.get("receipt_url"):
            msg += "📎 <b>Чек прикреплен к заказу!</b>\n"
        else:
            msg += "⏳ <b>Ожидается чек от клиента.</b>\n"

    # Action inline buttons for admin
    inline_kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Принять заказ", callback_data=f"status:{order_id}:preparing"),
            InlineKeyboardButton(text="🚚 На доставку", callback_data=f"status:{order_id}:delivering"),
        ],
        [
            InlineKeyboardButton(text="📦 Открыть в админке", web_app=WebAppInfo(url=f"{WEBAPP_URL}?admin=true&order={order_id}"))
        ]
    ])

    for admin_id in ADMIN_IDS:
        try:
            if receipt_bytes:
                await bot.send_photo(
                    chat_id=admin_id,
                    photo=types.BufferedInputFile(receipt_bytes, filename=f"receipt_{order_num}.jpg"),
                    caption=msg,
                    reply_markup=inline_kb
                )
            else:
                await bot.send_message(
                    chat_id=admin_id,
                    text=msg,
                    reply_markup=inline_kb
                )
        except Exception as e:
            logger.error(f"Failed to send order notification to admin {admin_id}: {e}")


@dp.callback_query(F.data.startswith("status:"))
async def handle_status_callback(query: types.CallbackQuery):
    if not is_admin(query.from_user.id):
        await query.answer("У вас нет прав администратора.", show_alert=True)
        return

    parts = query.data.split(":")
    if len(parts) == 3:
        _, order_id, new_status = parts
        status_labels = {
            "preparing": "👨‍🍳 Готовится",
            "delivering": "🚚 Доставляется",
            "completed": "✅ Выполнен",
            "cancelled": "❌ Отменен",
            "paid": "✅ Оплата подтверждена"
        }
        label = status_labels.get(new_status, new_status)
        await query.answer(f"Статус обновлен на: {label}")
        await query.message.reply(f"ℹ️ Администратор {query.from_user.first_name} изменил статус заказа на: <b>{label}</b>")


async def main():
    if not bot:
        logger.error("BOT_TOKEN is not configured in .env! Exiting bot runner.")
        return
    logger.info("Starting Telegram Bot for Mecca Halal Store...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
