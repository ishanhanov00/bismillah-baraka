"""
SQLAlchemy models for Mecca Halal Food & Sadaqah Store.
Compatible with SQLite and easily switchable to PostgreSQL.
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, Boolean, Text, DateTime, ForeignKey, Index, Enum
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(Integer, unique=True, index=True, nullable=True)
    username = Column(String(100), nullable=True)
    full_name = Column(String(150), nullable=True)
    phone = Column(String(50), nullable=True, index=True)
    language = Column(String(10), default="ru")
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    orders = relationship("Order", back_populates="user")


class Category(Base):
    __tablename__ = "categories"

    id = Column(String(50), primary_key=True)  # e.g., 'our_set', 'breakfast', 'soup', 'main', 'sadaqah_food'
    section = Column(String(20), nullable=False, index=True)  # 'menu' or 'sadaqah'
    name_ru = Column(String(100), nullable=False)
    name_uz = Column(String(100), nullable=False)
    name_ar = Column(String(100), nullable=False)
    name_en = Column(String(100), nullable=False)
    icon = Column(String(20), default="🍽")
    sort_order = Column(Integer, default=0)

    products = relationship("Product", back_populates="category_rel")


class Product(Base):
    __tablename__ = "products"

    id = Column(String(50), primary_key=True)
    section = Column(String(20), nullable=False, index=True)  # 'menu' or 'sadaqah'
    category_id = Column(String(50), ForeignKey("categories.id"), nullable=False, index=True)
    
    # Multilingual Names
    name_ru = Column(String(200), nullable=False)
    name_uz = Column(String(200), nullable=False)
    name_ar = Column(String(200), nullable=False)
    name_en = Column(String(200), nullable=False)

    # Multilingual Descriptions
    description_ru = Column(Text, default="")
    description_uz = Column(Text, default="")
    description_ar = Column(Text, default="")
    description_en = Column(Text, default="")

    price = Column(Float, nullable=False)  # in SAR
    stock = Column(Integer, default=0, nullable=False)  # Current inventory quantity
    photo_url = Column(String(500), default="")
    is_available = Column(Boolean, default=True, index=True)
    is_set = Column(Boolean, default=False)  # Set combo flag
    min_quantity = Column(Integer, default=1)
    max_quantity = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    category_rel = relationship("Category", back_populates="products")
    order_items = relationship("OrderItem", back_populates="product")
    inventory_logs = relationship("InventoryTransaction", back_populates="product")

    __table_args__ = (
        Index("idx_product_section_available", "section", "is_available"),
    )


class Order(Base):
    __tablename__ = "orders"

    id = Column(String(60), primary_key=True)
    order_number = Column(Integer, unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    client_telegram_id = Column(Integer, nullable=True, index=True)
    client_telegram_username = Column(String(100), nullable=True)
    
    client_name = Column(String(150), nullable=False)
    client_phone = Column(String(50), nullable=False, index=True)
    
    delivery_type = Column(String(20), default="delivery")  # 'delivery' or 'pickup'
    delivery_address = Column(String(300), nullable=False)   # in Mecca
    comment = Column(Text, nullable=True)
    
    total_amount = Column(Float, nullable=False)  # in SAR
    payment_method = Column(String(20), nullable=False)  # 'cash' or 'transfer'
    receipt_url = Column(String(500), nullable=True)     # Bank receipt screenshot
    
    # Statuses: new, pending_payment, verifying_payment, paid, preparing, ready, delivering, completed, cancelled
    status = Column(String(30), default="new", nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="orders")
    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")


class OrderItem(Base):
    __tablename__ = "order_items"

    id = Column(Integer, primary_key=True, autoincrement=True)
    order_id = Column(String(60), ForeignKey("orders.id"), nullable=False, index=True)
    product_id = Column(String(50), ForeignKey("products.id"), nullable=False)
    product_name = Column(String(200), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Float, nullable=False)
    subtotal = Column(Float, nullable=False)

    order = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")


class InventoryTransaction(Base):
    __tablename__ = "inventory_transactions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(String(50), ForeignKey("products.id"), nullable=False, index=True)
    order_id = Column(String(60), nullable=True)
    delta = Column(Integer, nullable=False)  # negative on purchase, positive on cancel/restock
    stock_before = Column(Integer, nullable=False)
    stock_after = Column(Integer, nullable=False)
    reason = Column(String(100), nullable=False)  # 'order_placed', 'order_cancelled', 'manual_restock'
    created_at = Column(DateTime, default=datetime.utcnow)

    product = relationship("Product", back_populates="inventory_logs")


class BusinessSetting(Base):
    __tablename__ = "business_settings"

    key = Column(String(50), primary_key=True)
    value = Column(Text, nullable=False)
