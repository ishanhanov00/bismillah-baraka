"""
Seed script to populate initial categories, products, sets, and store settings.
Run with: python -m database.seed
"""
import asyncio
import json
from .db import AsyncSessionLocal, init_db
from .models import Category, Product, BusinessSetting

async def seed_data():
    await init_db()
    async with AsyncSessionLocal() as session:
        # Check if already seeded
        existing_cat = await session.get(Category, "our_set")
        if existing_cat:
            print("Database already contains data. Skipping seed.")
            return

        print("Seeding categories...")
        categories = [
            # Menu Categories
            Category(id="our_set", section="menu", name_ru="⭐ Наш сет", name_uz="⭐ Bizning to‘plam", name_ar="⭐ بوكس خاص", name_en="⭐ Our Special Set", icon="⭐", sort_order=1),
            Category(id="breakfast", section="menu", name_ru="🍳 Завтрак", name_uz="🍳 Nonushta", name_ar="🍳 فطور", name_en="🍳 Breakfast", icon="🍳", sort_order=2),
            Category(id="soup", section="menu", name_ru="🍲 Первые блюда", name_uz="🍲 Suyuq taomlar", name_ar="🍲 شوربات", name_en="🍲 Soups", icon="🍲", sort_order=3),
            Category(id="main", section="menu", name_ru="🍛 Вторые блюда", name_uz="🍛 Quyuq taomlar", name_ar="🍛 أطباق رئيسية", name_en="🍛 Main Dishes", icon="🍛", sort_order=4),
            Category(id="salad", section="menu", name_ru="🥗 Салаты", name_uz="🥗 Salatlar", name_ar="🥗 سلطات", name_en="🥗 Salads", icon="🥗", sort_order=5),
            Category(id="drink", section="menu", name_ru="🥤 Напитки", name_uz="🥤 Ichimliklar", name_ar="🥤 مشروبات", name_en="🥤 Drinks", icon="🥤", sort_order=6),
            
            # Sadaqah Categories
            Category(id="sadaqah_food", section="sadaqah", name_ru="🍛 Садака едой", name_uz="🍛 Taom sadaqasi", name_ar="🍛 صدقة إطعام طعام", name_en="🍛 Sadaqah Food", icon="🍛", sort_order=1),
            Category(id="sadaqah_drink", section="sadaqah", name_ru="🥤 Садака водой", name_uz="🥤 Suv sadaqasi", name_ar="🥤 صدقة سقيا ماء", name_en="🥤 Sadaqah Water", icon="🥤", sort_order=2),
            Category(id="sadaqah_meal", section="sadaqah", name_ru="🍲 Комплексный обед", name_uz="🍲 To‘liq tushlik", name_ar="🍲 وجبة كاملة للمحتاجين", name_en="🍲 Complete Pilgrim Meal", icon="🍲", sort_order=3),
            Category(id="sadaqah_other", section="sadaqah", name_ru="🤲 Другие виды садака", name_uz="🤲 Boshqa sadaqalar", name_ar="🤲 صدقات أخرى", name_en="🤲 Other Sadaqah", icon="🤲", sort_order=4),
        ]
        session.add_all(categories)

        print("Seeding initial products...")
        products = [
            # ⭐ НАШ СЕТ
            Product(
                id="prod-set-1",
                section="menu",
                category_id="our_set",
                is_set=True,
                name_ru="⭐ Наш фирменный Сет «Мекка Премиум»",
                name_uz="⭐ Bizning maxsus to‘plam «Makka Premium»",
                name_ar="⭐ بوكس مكة بريميوم الملكي الخاص",
                name_en="⭐ Our Special Set 'Mecca Premium Combo'",
                description_ru="Королевский плов с нежной бараниной, наваристая шурпа, свежий салат ачичук, тандырная лепешка и айран.",
                description_uz="Qo‘zichoq go‘shtli shohona palov, sho‘rva, yangi achchiq-chuchuk salati, tandir noni va barra ayron.",
                description_ar="أرز بخاري باللحم الطازج الفاخر، شوربة لحم غنية، سلطة طازجة، خبز التنور الحار، ومشروب لبن منعش.",
                description_en="Royal Lamb Pilaf, hearty Lamb Shorba soup, fresh tomato Achichuk salad, hot flatbread, and cold Ayran drink.",
                price=45.0,
                stock=12,
                photo_url="https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),
            Product(
                id="prod-set-2",
                section="menu",
                category_id="our_set",
                is_set=True,
                name_ru="⭐ Семейный Сет «Кабса & Манди» (на 3-4 персоны)",
                name_uz="⭐ Oilaviy to‘plam «Kabsa & Mandi» (3-4 kishi)",
                name_ar="⭐ بوكس العائلة الخاص مندي وكبسة (3-4 أشخاص)",
                name_en="⭐ Family Special Set 'Kabsa & Mandi' (3-4 persons)",
                description_ru="Большое блюдо арабского Манди с цыпленком и говяжьей Кабсой, 2 салата, 4 соуса даккус, 4 тандырные лепешки и 4 бутылки Замзам.",
                description_uz="Tovuqli Mandi va mol go‘shtli Kabsa katta patnisi, 2 xil salat, souslar va 4 dona Zamzam suvi.",
                description_ar="صينية عائلية مشكلة مندي دجاج وكبسة لحم مع صوصات الدقوس، سلطات خضراء، و4 مياه زمزم.",
                description_en="Large family platter of Chicken Mandi and Beef Kabsa, 2 salads, 4 sauces, 4 flatbreads, and 4 Zamzam bottles.",
                price=95.0,
                stock=6,
                photo_url="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),

            # 🍳 ЗАВТРАК
            Product(
                id="prod-brk-1",
                section="menu",
                category_id="breakfast",
                name_ru="Шакшука по-восточному со свежим хлебом",
                name_uz="Sharqona shakshuka issiq non bilan",
                name_ar="شكشوكة عربية فاخرة مع الخبز الساخن",
                name_en="Oriental Shakshuka with Fresh Bread",
                description_ru="Яичница с сочными томатами, сладким перцем, восточными пряностями и свежей лепешкой из тандыра.",
                description_uz="Pomidor va sabzavotlar bilan tayyorlangan barra tuxum, issiq non bilan.",
                description_ar="بيض مطهو مع الطماطم الطازجة والفلفل والبهارات الشرقية يقدم مع خبز تنور طازج.",
                description_en="Eggs poached in rich spiced tomato sauce, served with warm flatbread.",
                price=22.0,
                stock=15,
                photo_url="https://images.unsplash.com/photo-1590412200988-a436970781fa?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),

            # 🍲 ПЕРВЫЕ БЛЮДА
            Product(
                id="prod-soup-1",
                section="menu",
                category_id="soup",
                name_ru="Шурпа из свежей баранины (Кой шурва)",
                name_uz="Yangi qo‘y go‘shtli to‘yimli sho‘rva",
                name_ar="شوربة لحم الضأن الطازج بالخضار",
                name_en="Rich Lamb Shorba Soup with Vegetables",
                description_ru="Наваристый прозрачный бульон из свежей местной баранины с крупными овощами, нутом и восточной зеленью.",
                description_uz="Yangi barra qo‘y go‘shti, no‘xat va sarxil sabzavotlar bilan tayyorlangan sho‘rva.",
                description_ar="مرق لحم ضأن طازج وغني مع الحمص، الجزر، البطاطس، والأعشاب العطرية.",
                description_en="Clear aromatic broth cooked with fresh tender lamb, chickpeas, whole potatoes, and herbs.",
                price=25.0,
                stock=14,
                photo_url="https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),

            # 🍛 ВТОРЫЕ БЛЮДА
            Product(
                id="prod-main-1",
                section="menu",
                category_id="main",
                name_ru="Праздничный Плов с бараниной по-бухарски",
                name_uz="Buxorocha to‘y oshi (Qo‘y go‘shti bilan)",
                name_ar="أرز بخاري ملكي باللحم والمكسرات",
                name_en="Festive Bukhara Lamb Pilaf",
                description_ru="Нежнейшая баранина, отборный рис Лазер, сочная сладкая морковь, изюм, барбарис и восточные специи.",
                description_uz="Sara Lazer guruchi, mayin qo‘zi go‘shti, sariq sabzi, mayiz va zira bilan damlangan palov.",
                description_ar="أرز بخاري فاخر مطبوخ بالسمن البلدي مع قطع لحم ضأن طري، جزر أصفر، زبيب وبهارات أصيلة.",
                description_en="Premium long grain rice cooked with tender lamb cuts, yellow carrots, and raisins.",
                price=32.0,
                stock=20,
                photo_url="https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),
            Product(
                id="prod-main-2",
                section="menu",
                category_id="main",
                name_ru="Арабский Манди с нежным цыпленком",
                name_uz="Arabcha Mandi tovuq go‘shti bilan",
                name_ar="مندي دجاج حجازي على أصوله",
                name_en="Arabic Mandi with Roasted Chicken",
                description_ru="Ароматный рис басмати с дымком, запеченная половина сочного цыпленка, острый соус Даккус.",
                description_uz="Dudlangan basmati guruch, yumshoq qovurilgan tovuq go‘shti va maxsus achchiq sous.",
                description_ar="أرز بسمتي مدخن بالطريقة التقليدية مع نصف دجاجة محمرة بتتبيلة مميزة وصوص الدقوس الحار.",
                description_en="Traditional smoked basmati rice with half seasoned roast chicken and spicy Dakkous sauce.",
                price=28.0,
                stock=10,
                photo_url="https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),

            # 🥤 НАПИТКИ
            Product(
                id="prod-drk-1",
                section="menu",
                category_id="drink",
                name_ru="Священная вода Замзам (оригинал, 330 мл)",
                name_uz="Muborak Zamzam suvi (330 ml)",
                name_ar="ماء زمزم المبارك المعبأ الأصلي (330 مل)",
                name_en="Blessed Zamzam Water (Original, 330ml)",
                description_ru="Оригинальная бутилированная вода Замзам из Мекки, освященная и очищенная.",
                description_uz="Makka shahridagi asl va muborak Zamzam suvi, qadoqlangan shisha.",
                description_ar="ماء زمزم المبارك النقي معبأ من مصنع الملك عبد الله لسقيا زمزم بمكة المكرمة.",
                description_en="Authentic bottled Zamzam water sourced from the blessed well in Mecca.",
                price=5.0,
                stock=50,
                photo_url="https://images.unsplash.com/photo-1548839140-29a749e1bc4e?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),

            # 🤲 САДАКА
            Product(
                id="prod-sad-1",
                section="sadaqah",
                category_id="sadaqah_food",
                name_ru="Садака: Горячий сытный обед для паломников в Мекке",
                name_uz="Sadaqa: Makkadagi ziyoratchilar uchun issiq tushlik",
                name_ar="صدقة: إطعام وجبة ساخنة لحجاج ومعتمري بيت الله الحرام",
                name_en="Sadaqah: Hot Nutritious Meal for Pilgrims in Mecca",
                description_ru="Мы лично приготовим и бесплатно раздадим порцию горячего плова или манди с мясом, хлебом и водой нуждающимся или паломникам в районе Аль-Харам.",
                description_uz="Haram hududidagi hojilar va muhtojlarga issiq go‘shtli taom, non va suv ehson qilib tarqatiladi.",
                description_ar="وجبة متكاملة (أرز ولحم طازج + ماء + تمر + خبز) يتم توزيعها في ساحات المسجد الحرام على الصائمين وضيوف الرحمن.",
                description_en="A freshly prepared meal containing rice, halal meat, fresh bread, and water distributed in the holy precinct of Mecca.",
                price=20.0,
                stock=100,
                photo_url="https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            ),
            Product(
                id="prod-sad-2",
                section="sadaqah",
                category_id="sadaqah_drink",
                name_ru="Садака: Упаковка холодной воды (24 бутылки по 330 мл)",
                name_uz="Sadaqa: Muzdek ichimlik suvi to‘plami (24 dona)",
                name_ar="صدقة: كرتون سقيا ماء بارد للمصلين بالحرم (24 عبوة)",
                name_en="Sadaqah: Pack of Chilled Drinking Water (24 x 330ml bottles)",
                description_ru="Раздача чистой питьевой воды верующим и молящимся в жару возле мечетей и святынь Мекки.",
                description_uz="Makka masjidlari atrofida issiq havoda namozxonlarga tarqatiladigan 24 dona toza suv.",
                description_ar="توزيع كرتون ماء صحي مبرد على المصلين والمعتمرين في أوقات الصلوات والظهيرة.",
                description_en="Distribution of 24 bottles of chilled clean water to worshippers and visitors around Mecca holy sites.",
                price=25.0,
                stock=50,
                photo_url="https://images.unsplash.com/photo-1559839914-ba2ac679a9ef?auto=format&fit=crop&w=600&q=80",
                is_available=True,
                min_quantity=1
            )
        ]
        session.add_all(products)

        print("Seeding business settings...")
        settings_data = {
            "business_name": "Мекка Халяль & Садака",
            "logo_url": "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=300&q=80",
            "description": "Вкусная домашняя халяль еда с доставкой по Мекке. Организация садака для паломников.",
            "phone": "+966 54 812 3456",
            "whatsapp": "+966548123456",
            "instagram": "@mecca_halal_food",
            "address": "г. Мекка, район Аль-Азизия, возле мечети Аль-Раджи",
            "work_hours": "09:00 — 23:30",
            "is_open": "true",
            "open_time": "09:00",
            "close_time": "23:30",
            "allow_orders_when_closed": "false",
            "currency": "SAR",
            "pickup_enabled": "true",
            "bank_name": "Al Rajhi Bank (مصرف الراجحي)",
            "account_holder": "MECCA HALAL KITCHEN CO.",
            "iban": "SA4580000201608010123456",
            "account_number": "201608010123456",
            "instruction": "При переводе в комментарии укажите номер вашего заказа. После завершения перевода прикрепите фото или скриншот чека в приложении."
        }

        for k, v in settings_data.items():
            session.add(BusinessSetting(key=k, value=str(v)))

        await session.commit()
        print("Database seed completed successfully!")

if __name__ == "__main__":
    asyncio.run(seed_data())
