#!/usr/bin/env bash
set -e

echo "=== Запуск Telegram-магазина Мекка Халяль & Садака ==="

if [ ! -f .env ]; then
    echo "⚠️ Файл .env не найден! Копирую из .env.example..."
    cp .env.example .env
    echo "❗ Пожалуйста, откройте .env и укажите ваш BOT_TOKEN и ADMIN_IDS!"
fi

echo "1. Проверка виртуального окружения..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

source venv/bin/activate
pip install -r requirements.txt

echo "2. Инициализация базы данных и сидинг блюд Мекки..."
python3 -m database.seed

echo "3. Запуск Backend и Telegram-бота..."
# Запуск FastAPI в фоне
uvicorn backend.main:app --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!

# Запуск Aiogram бота
python3 -m bot.main &
BOT_PID=$!

trap "kill $BACKEND_PID $BOT_PID" EXIT

wait
